// assets/js/main.js

// 1. DATA PUSAT (Agar tidak kena error CORS/Gagal muat)
const gamesData = [
    { "id": 1, "title": "Cyberpunk 2077", "price": "Rp 15.000", "image": "assets/img/games/cyberpunk-2077.jpg", "url": "magnet:?xt=urn:btih:C9D3921BF7017490C74D546C3D0FD6F1E0694422&dn=Cyberpunk+2077%3A+Ultimate+Edition+%28v2.3+%2B+All+DLCs+%2B+Bonus+Content+%2B+REDmod%2C+MULTi19%29+%5BFitGirl+Repack%2C+Selective+Download+-+from+55.7+GB%5D&tr=udp%3A%2F%2Fopentor.net%3A6969&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.theoks.net%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.ccp.ovh%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=udp%3A%2F%2Fopen.stealth.si%3A80%2Fannounce&tr=https%3A%2F%2Ftracker.tamersunion.org%3A443%2Fannounce&tr=udp%3A%2F%2Fexplodie.org%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.bt4g.com%3A2095%2Fannounce&tr=udp%3A%2F%2Fbt2.archive.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fbt1.archive.org%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.filemail.com%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker1.bt.moack.co.kr%3A80%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce" },
    { "id": 2, "title": "Elden Ring", "price": "Rp 12.000", "image": "assets/img/games/elden-ring.jpg", "url": "magnet:?xt=urn:btih:4CC8E331E699748269F6AC1B98B802684F5AC97A&dn=ELDEN+RING%3A+Shadow+of+the+Erdtree+Deluxe+Edition+%28v1.12%2Fv1.12.1+%2B+9+DLCs%2FBonuses+%2B+Windows+7+Fix%2C+MULTi14%29+%5BFitGirl+Repack%2C+Selective+Download+-+from+47.4+GB%5D&tr=udp%3A%2F%2Fopentor.net%3A6969&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.gbitt.info%3A80%2Fannounce&tr=http%3A%2F%2Ftracker.ccp.ovh%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.ccp.ovh%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fexodus.desync.com%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.theoks.net%3A6969%2Fannounce&tr=https%3A%2F%2Ftracker.tamersunion.org%3A443%2Fannounce&tr=http%3A%2F%2Fopen.acgnxtracker.com%3A80%2Fannounce&tr=http%3A%2F%2Fopen.acgtracker.com%3A1096%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce" },
    { "id": 3, "title": "GTA V: Premium Edition", "price": "Rp 10.000", "image": "assets/img/games/gta-v.jpg", "url": "magnet:?xt=urn:btih:8D003359419C09B9E7202044D7F8738A9CE496E1&dn=Grand+Theft+Auto+V+%28v1.0.3725.0%2F1.72+%2B+Bonus+Content%2C+MULTi13%29+%5BFitGirl+Repack%2C+Selective+Download+-+from+51.2+GB%5D&tr=udp%3A%2F%2Fopentor.net%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.qu.ax%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.fnix.net%3A6969%2Fannounce&tr=udp%3A%2F%2Fevan.im%3A6969%2Fannounce&tr=udp%3A%2F%2Fmartin-gebhardt.eu%3A25%2Fannounce&tr=https%3A%2F%2Fshahidrazi.online%3A443%2Fannounce&tr=http%3A%2F%2Fwegkxfcivgx.ydns.eu%3A80%2Fannounce&tr=http%3A%2F%2Flucke.fenesisu.moe%3A6969%2Fannounce&tr=udp%3A%2F%2Fextracker.dahrkael.net%3A6969%2Fannounce&tr=https%3A%2F%2Ftracker.alaskantf.com%3A443%2Fannounce&tr=https%3A%2F%2Ftracker.qingwa.pro%3A443%2Fannounce&tr=udp%3A%2F%2Ftracker.playground.ru%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce" },
    { "id": 4, "title": "Red Dead Redemption 2", "price": "Rp 15.000", "image": "assets/img/games/rdr2.jpg", "url": "magnet:?xt=urn:btih:18A89755E51616C9E8E904FF360E364DEB4B0922&dn=Red+Dead+Redemption+2%3A+Ultimate+Edition+%28Build+1491.50+%2B+UE+Unlocker%2C+MULTi13%29+%5BFitGirl+Repack%5D&tr=udp%3A%2F%2Fopentor.net%3A6969&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=http%3A%2F%2Ftracker.gbitt.info%3A80%2Fannounce&tr=http%3A%2F%2Ftracker.ccp.ovh%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.ccp.ovh%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fexodus.desync.com%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.theoks.net%3A6969%2Fannounce&tr=https%3A%2F%2Ftracker.tamersunion.org%3A443%2Fannounce&tr=http%3A%2F%2Fopen.acgnxtracker.com%3A80%2Fannounce&tr=http%3A%2F%2Fopen.acgtracker.com%3A1096%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce" },
    { "id": 5, "title": "Battlefield 6 (Campaign Only)", "price": "Rp 20.000", "image": "assets/img/games/bf6.jpg", "url": "magnet:?xt=urn:btih:11B7A81A6CF1E646FDECBD9BAB71CCF3DEF32652&dn=Battlefield+6+%28v1.1.2.0+%2B+Bonus+OST%2C+MULTi13%29+%5BFitGirl+Repack%2C+Selective+Download+-+from+35.8+GB%5D&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.qu.ax%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.fnix.net%3A6969%2Fannounce&tr=udp%3A%2F%2Fevan.im%3A6969%2Fannounce&tr=udp%3A%2F%2Fmartin-gebhardt.eu%3A25%2Fannounce&tr=https%3A%2F%2Fshahidrazi.online%3A443%2Fannounce&tr=http%3A%2F%2Fwegkxfcivgx.ydns.eu%3A80%2Fannounce&tr=http%3A%2F%2Flucke.fenesisu.moe%3A6969%2Fannounce&tr=udp%3A%2F%2Fextracker.dahrkael.net%3A6969%2Fannounce&tr=https%3A%2F%2Ftracker.alaskantf.com%3A443%2Fannounce&tr=https%3A%2F%2Ftracker.qingwa.pro%3A443%2Fannounce&tr=udp%3A%2F%2Ftracker.playground.ru%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.skynetcloud.site%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce" },
    { "id": 6, "title": "Call of Duty: Black Ops-Cold War(ALL DLC)", "price": "Rp 25.000", "image": "assets/img/games/coldwar.jpg", "url": "magnet:?xt=urn:btih:3811BD1E97CED25C97CD7F2972CA96BBF7104A74&dn=Call+of+Duty%3A+Black+Ops+-+Cold+War+%28v1.34.1.15931218+%2B+All+DLCs+and+Modes+%2B+Bonus+OST%2C+MULTi13%29+%5BFitGirl+Repack%2C+Selective+Download+-+from+60+GB%5D&tr=udp%3A%2F%2Fopentor.net%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.torrent.eu.org%3A451%2Fannounce&tr=udp%3A%2F%2Ftracker.qu.ax%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.fnix.net%3A6969%2Fannounce&tr=udp%3A%2F%2Fevan.im%3A6969%2Fannounce&tr=udp%3A%2F%2Fmartin-gebhardt.eu%3A25%2Fannounce&tr=https%3A%2F%2Fshahidrazi.online%3A443%2Fannounce&tr=http%3A%2F%2Fwegkxfcivgx.ydns.eu%3A80%2Fannounce&tr=http%3A%2F%2Flucke.fenesisu.moe%3A6969%2Fannounce&tr=udp%3A%2F%2Fextracker.dahrkael.net%3A6969%2Fannounce&tr=https%3A%2F%2Ftracker.alaskantf.com%3A443%2Fannounce&tr=https%3A%2F%2Ftracker.qingwa.pro%3A443%2Fannounce&tr=udp%3A%2F%2Ftracker.playground.ru%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337%2Fannounce&tr=http%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce&tr=udp%3A%2F%2Fopentracker.i2p.rocks%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.internetwarriors.net%3A1337%2Fannounce&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969%2Fannounce&tr=udp%3A%2F%2Fcoppersurfer.tk%3A6969%2Fannounce&tr=udp%3A%2F%2Ftracker.zer0day.to%3A1337%2Fannounce" }
];

let selectedGameId = null;

// 2. FUNGSI UNTUK NAMPILIN GAME DI HOME (index.html)
function renderStore() {
    const storeGrid = document.getElementById('store-grid');
    if (!storeGrid) return; // Supaya tidak error kalau dibuka di halaman lain

    storeGrid.innerHTML = ''; // Hapus tulisan "Memuat..."
    
    gamesData.forEach(game => {
        storeGrid.innerHTML += `
            <div class="game-card">
                <img src="${game.image}" alt="${game.title}" onerror="this.src='https://via.placeholder.com/400x600?text=No+Image'">
                <div class="game-info">
                    <h4>${game.title}</h4>
                    <p class="price">${game.price}</p>
                    <button class="btn-primary" style="width: 100%; margin-top: 15px;" onclick="showReceipt(${game.id})">Beli Sekarang</button>
                </div>
            </div>`;
    });
}

// 3. FUNGSI UNTUK NAMPILIN GAME DI LIBRARY (library.html)
function renderLibrary() {
    const libraryGrid = document.getElementById('library-grid');
    if (!libraryGrid) return;

    const purchasedIds = JSON.parse(localStorage.getItem('myGames')) || [];
    
    if (purchasedIds.length === 0) {
        libraryGrid.innerHTML = `<p style="grid-column: 1/-1; text-align: center; color: #86868b; padding: 50px;">Koleksi masih kosong. Yuk belanja dulu!</p>`;
        return;
    }

    libraryGrid.innerHTML = '';
    const myGames = gamesData.filter(game => purchasedIds.includes(game.id));

    myGames.forEach(game => {
        libraryGrid.innerHTML += `
            <div class="game-card">
                <img src="${game.image}" alt="${game.title}">
                <div class="game-info">
                    <span style="background: rgba(255,255,255,0.1); padding: 4px 8px; border-radius: 4px; font-size: 10px;">PURCHASED</span>
                    <h4 style="margin-top: 10px;">${game.title}</h4>
                    <button class="btn-primary" style="width: 100%; margin-top: 15px; background: white; color: black;" onclick="window.location.href='${game.url}'">Download Game</button>
                </div>
            </div>`;
    });
}

// 4. LOGIKA MODAL QRIS & GIMMICK MENUNGGU
function showReceipt(gameId) {
    const game = gamesData.find(g => g.id === gameId);
    if (!game) return;

    selectedGameId = gameId;

    // Reset Tampilan Tombol Konfirmasi
    const btn = document.getElementById('confirm-btn');
    if (btn) {
        btn.innerHTML = "Konfirmasi Pembayaran";
        btn.disabled = false;
        btn.style.opacity = "1";
    }

    // Isi Data ke Nota
    const nameElem = document.getElementById('receipt-item-name');
    const priceElem = document.getElementById('receipt-price');
    const modal = document.getElementById('receipt-modal');

    if (nameElem) nameElem.innerText = game.title;
    if (priceElem) priceElem.innerText = game.price;
    if (modal) modal.style.display = 'flex';
}

function startConfirmation() {
    const btn = document.getElementById('confirm-btn');
    if (!btn) return;

    // Mulai Gimmick Loading
    btn.disabled = true;
    btn.style.opacity = "0.7";
    btn.innerHTML = `<span class="loading-spinner"></span> Menunggu Konfirmasi Admin...`;

    // Nunggu 3 Detik (Gimmick)
    setTimeout(() => {
        completePurchase();
    }, 3000);
}

function completePurchase() {
    if (!selectedGameId) return;

    let purchasedIds = JSON.parse(localStorage.getItem('myGames')) || [];
    if (!purchasedIds.includes(selectedGameId)) {
        purchasedIds.push(selectedGameId);
        localStorage.setItem('myGames', JSON.stringify(purchasedIds));
    }
    
    alert("Pembayaran Terverifikasi! Game sudah tersedia di Library.");
    window.location.href = 'library.html';
}

function closeReceipt() {
    const modal = document.getElementById('receipt-modal');
    if (modal) modal.style.display = 'none';
}

// 5. JALANKAN SEMUA SAAT HALAMAN SIAP
document.addEventListener('DOMContentLoaded', () => {
    renderStore();
    renderLibrary();
});