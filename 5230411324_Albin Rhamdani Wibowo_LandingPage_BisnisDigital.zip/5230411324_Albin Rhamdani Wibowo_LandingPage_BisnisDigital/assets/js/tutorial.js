// assets/js/tutorial.js

let currentStep = 1;
const totalSteps = 4;

function moveStep(n) {
    const currentContent = document.getElementById(`step-${currentStep}`);
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');

    if (!currentContent) return;

    // Sembunyikan step sekarang dengan sedikit delay untuk animasi (opsional)
    currentContent.classList.remove('active');
    
    // Update index langkah
    currentStep += n;

    // Pastikan tidak melampaui batas
    if (currentStep < 1) currentStep = 1;
    if (currentStep > totalSteps) currentStep = totalSteps;

    // Tampilkan step yang baru
    const nextContent = document.getElementById(`step-${currentStep}`);
    if (nextContent) nextContent.classList.add('active');

    // Update status tombol navigasi
    if (prevBtn) prevBtn.disabled = (currentStep === 1);
    if (nextBtn) nextBtn.disabled = (currentStep === totalSteps);
}