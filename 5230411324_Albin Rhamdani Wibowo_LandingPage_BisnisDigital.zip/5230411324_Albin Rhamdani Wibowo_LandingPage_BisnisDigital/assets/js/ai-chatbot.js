const API_KEY = "AIzaSyCk8qoHgyGulxUqzXsNKmqHxCyI_tuGHJQ";

function toggleChat() {
    const win = document.getElementById('chat-window');
    if (win) {
        win.style.display = win.style.display === 'flex' ? 'none' : 'flex';
    }
}

function handleKeyPress(e) {
    if (e.key === 'Enter') sendMessage();
}

async function sendMessage() {
    const input = document.getElementById('user-input');
    const sendBtn = document.querySelector('.chat-input-area button');
    const msgContainer = document.getElementById('chat-messages');
    const userText = input.value.trim();

    // Validasi input dan cegah spam saat bot masih memproses
    if (!userText || (sendBtn && sendBtn.disabled)) return;

    // 1. Tampilkan pesan pengguna di UI
    msgContainer.innerHTML += `<div class="msg user">${userText}</div>`;
    input.value = ''; // Reset input
    
    // Nonaktifkan tombol kirim (Anti-Spam)
    if (sendBtn) {
        sendBtn.disabled = true;
        sendBtn.style.opacity = "0.5";
    }

    msgContainer.scrollTop = msgContainer.scrollHeight;

    // 2. State Loading ala Apple
    const botMsgId = "bot-" + Date.now();
    msgContainer.innerHTML += `<div class="msg bot" id="${botMsgId}"><span class="loading-spinner"></span> Memproses...</div>`;
    msgContainer.scrollTop = msgContainer.scrollHeight;

    try {
        // 3. Request ke Gemini 2.0 Flash API
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: `Context: Kamu adalah Vault. AI, asisten premium dari startup 'Vault. One'. 
                        Tugas: Membantu gamer PC cek spesifikasi, berita game, dan info katalog secara singkat dan ramah.
                        Data Katalog: 
                        - Cyberpunk 2077: RAM 12GB, GPU GTX 1060.
                        - Elden Ring: RAM 12GB, GPU GTX 1060.
                        - GTA V: RAM 8GB, GPU GTX 660.
                        Pertanyaan User: ${userText}`
                    }]
                }]
            })
        });

        const data = await response.json();
        
        // Penanganan jika kuota habis (Error 429) atau error lainnya
        if (response.status === 429) {
            throw new Error("Kuota harian habis. Coba lagi nanti.");
        } else if (data.error) {
            throw new Error(data.error.message);
        }

        const aiResponse = data.candidates[0].content.parts[0].text;
        
        // 4. Tampilkan Jawaban AI
        document.getElementById(botMsgId).innerText = aiResponse;

    } catch (error) {
        console.error("Vault. AI Error:", error);
        document.getElementById(botMsgId).innerText = "Maaf, sistem sedang sibuk. Silakan tunggu 30 detik lalu coba lagi.";
    } finally {
        // 5. Aktifkan kembali tombol kirim
        if (sendBtn) {
            sendBtn.disabled = false;
            sendBtn.style.opacity = "1";
        }
        msgContainer.scrollTop = msgContainer.scrollHeight;
    }
}